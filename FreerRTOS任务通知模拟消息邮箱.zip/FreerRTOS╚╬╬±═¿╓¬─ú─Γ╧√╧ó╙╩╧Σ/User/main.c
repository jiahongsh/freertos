#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include "LED.h"
#include "FreeRTOS.h"
#include "task.h"
#include "OLED.h"
#include "Key.h"
#include "Serial.h"


uint8_t KeyNum;
 
//任务优先级
#define START_TASK_PRIO		 1
//任务堆栈大小	
#define START_TASK_STACK_SIZE 		128  
//任务句柄
TaskHandle_t StartTask_Handler;
//任务函数
void Start_Task(void *pvParameters);
 
//任务优先级
#define TASK1_PRIO		1
//任务堆栈大小	
#define TASK1_STK_SIZE 		128  
//任务句柄
TaskHandle_t Task1_Handler;
////任务函数
void Task1(void *pvParameters);

//任务优先级
#define TASK2_PRIO		1
//任务堆栈大小	
#define TASK2_STK_SIZE 		128  
//任务句柄
TaskHandle_t Task2_Handler;
////任务函数
void Task2(void *pvParameters);

 
int main(void)
{
    LED_Init();
	Key_Init();
    OLED_Init();
  
  //创建开始任务
  xTaskCreate((TaskFunction_t )Start_Task,            //任务函数
              (const char*    )"Start_Task",          //任务名称
              (uint16_t       )START_TASK_STACK_SIZE,        //任务堆栈大小
              (void*          )NULL,                  //传递给任务函数的参数
              (UBaseType_t    )START_TASK_PRIO,       //任务优先级
              (TaskHandle_t*  )&StartTask_Handler);   //任务句柄  
              
  vTaskStartScheduler();          //开启任务调度
  
}
 
//开始任务任务函数
void Start_Task(void *pvParameters)
{
    taskENTER_CRITICAL();//进入临界区
       
    //创建TASK1任务
    xTaskCreate((TaskFunction_t )Task1,     	
                (const char*    )"TASK1",   	
                (uint16_t       )TASK1_STK_SIZE, 
                (void*          )NULL,				
                (UBaseType_t    )TASK1_PRIO,	
                (TaskHandle_t*  )&Task1_Handler);  

    xTaskCreate((TaskFunction_t )Task2,     	
                (const char*    )"TASK2",   	
                (uint16_t       )TASK2_STK_SIZE, 
                (void*          )NULL,				
                (UBaseType_t    )TASK2_PRIO,	
                (TaskHandle_t*  )&Task2_Handler); 				
				
   
				
	
    
			

        vTaskDelete(NULL);
		taskEXIT_CRITICAL(); //退出临界区

}

void Task1(void *pvParameters)
{
	
	while(1)
	{
	  OLED_ShowString(3,1,"A:"); 
	
	  KeyNum=Key_GetNum(GPIO_Pin_11);
      if(KeyNum !=0&&Task2_Handler!=NULL)
	  {
		 xTaskNotify(Task2_Handler,KeyNum,eSetValueWithOverwrite);//给任务2发送通知,通知值为键值，采用复写模式  
		 OLED_ShowString(3,3,"A success");
	  }
	  vTaskDelay(10);
	 
	}
	
}


void Task2(void *pvParameters)
{
	
	uint32_t nitify_val=0;
	while(1)
	{
		OLED_ShowString(4,1,"B:");   
		
		xTaskNotifyWait(0,0xFFFFFFFF,&nitify_val,portMAX_DELAY);//	判断接受通知值是否成功，接受不成功，就阻塞    
		if(nitify_val!=0)
		{
	      OLED_ShowNum(4,3,nitify_val,2);
	      LED_Turn(GPIO_Pin_0);
		}
	    vTaskDelay(50);
	 
	}
	
}


